package com.example.emailreader

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import android.util.Base64
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.mail.*
import java.util.Properties
import kotlin.concurrent.thread

private data class MailAccount(
    val email: String,
    val password: String,
    val server: String,
    val protocol: String = "IMAPS",
    val port: Int = if (protocol == "POP3S") 995 else 993,
    var verified: Boolean = false
)

class MainActivity : Activity() {
    private lateinit var emailField: EditText
    private lateinit var passwordField: EditText
    private lateinit var serverField: EditText
    private lateinit var portField: EditText
    private lateinit var providerSpinner: Spinner
    private lateinit var protocolSpinner: Spinner
    private lateinit var status: TextView
    private lateinit var accountList: LinearLayout
    private lateinit var pendingList: LinearLayout
    private lateinit var searchPanel: LinearLayout
    private lateinit var accountPanel: LinearLayout
    private lateinit var searchField: EditText
    private lateinit var output: TextView
    private lateinit var connectedCount: TextView
    private lateinit var connectedHeading: TextView
    private lateinit var pendingHeading: TextView
    private val accounts = mutableListOf<MailAccount>()
    private val providers = listOf(
        "Auto-detect", "Gmail", "Outlook / Hotmail", "Yahoo",
        "Videotron", "Bell / Sympatico", "SaskTel", "Custom IMAP / POP"
    )
    private var searching = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        buildUi()
        renderAccounts()
        showAccounts()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 12)
        }
        root.addView(TextView(this).apply {
            text = "Emailv6"
            textSize = 27f
            setPadding(0, 0, 0, 4)
        })
        root.addView(TextView(this).apply {
            text = "Connect your mailboxes and search messages across them."
            textSize = 14f
            setPadding(0, 0, 0, 12)
        })
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabs.addView(button("Accounts") { showAccounts() }, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(button("Search all mail") { showSearch() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(tabs)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        accountPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        searchPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }

        providerSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, providers)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (::emailField.isInitialized) applyProviderDefaults()
                }
            }
        }
        emailField = edit("Email address")
        emailField.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) applyProviderDefaults() }
        passwordField = edit("Password or provider app password", true)
        serverField = edit("Incoming server")
        portField = edit("Incoming port (993 IMAPS / 995 POP3S)").apply {
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        protocolSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("IMAPS", "POP3S"))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (::portField.isInitialized) portField.setText(if (position == 1) "995" else "993")
                }
            }
        }
        accountPanel.addView(label("Provider"))
        accountPanel.addView(providerSpinner)
        accountPanel.addView(label("Email"))
        accountPanel.addView(emailField)
        accountPanel.addView(label("Password / app password"))
        accountPanel.addView(passwordField)
        accountPanel.addView(label("Incoming server"))
        accountPanel.addView(serverField)
        accountPanel.addView(label("Incoming port"))
        accountPanel.addView(portField)
        accountPanel.addView(label("Incoming protocol"))
        accountPanel.addView(protocolSpinner)
        accountPanel.addView(button("Auto-detect secure server") { autoDetectIncomingSettings() })
        accountPanel.addView(button("Add and verify account") { addAndVerifyAccount() })
        status = TextView(this).apply {
            text = "Ready"
            textSize = 14f
            setPadding(0, 12, 0, 12)
        }
        accountPanel.addView(status)
        connectedHeading = TextView(this).apply {
            text = "CONNECTED ACCOUNTS"
            textSize = 18f
            setPadding(0, 8, 0, 4)
        }
        accountPanel.addView(connectedHeading)
        connectedCount = TextView(this).apply { textSize = 13f }
        accountPanel.addView(connectedCount)
        accountList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        accountPanel.addView(accountList)
        val accountTabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        accountTabs.addView(button("Connected") { showAccountList(true) }, LinearLayout.LayoutParams(0, -2, 1f))
        accountTabs.addView(button("Pending / failed") { showAccountList(false) }, LinearLayout.LayoutParams(0, -2, 1f))
        accountPanel.addView(accountTabs)
        pendingHeading = TextView(this).apply {
            text = "PENDING / FAILED ACCOUNTS"
            textSize = 18f
            setPadding(0, 8, 0, 4)
            visibility = View.GONE
        }
        accountPanel.addView(pendingHeading)
        pendingList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        accountPanel.addView(pendingList)
        val help = TextView(this).apply {
            text = "Accounts are verified individually when you add them. Use provider-approved app passwords or OAuth where required. Credentials are encrypted on this device."
            textSize = 12f
            setPadding(0, 12, 0, 16)
        }
        accountPanel.addView(help)

        searchPanel.addView(TextView(this).apply {
            text = "Search message text, subjects and attachment filenames across every connected account's mail folders."
            textSize = 14f
            setPadding(0, 12, 0, 8)
        })
        searchField = edit("Search words or attachment filename")
        searchPanel.addView(searchField)
        searchPanel.addView(button("Search all connected accounts") { searchAllAccounts() })
        searchPanel.addView(button("Find messages with any attachment") {
            searchField.setText(" ")
            searchAllAccounts(attachmentsOnly = true)
        })
        output = TextView(this).apply {
            text = "Search results will appear here."
            textSize = 13f
            setPadding(0, 14, 0, 20)
        }
        searchPanel.addView(output)
        content.addView(accountPanel)
        content.addView(searchPanel)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showAccounts() {
        accountPanel.visibility = View.VISIBLE
        searchPanel.visibility = View.GONE
    }

    private fun showSearch() {
        accountPanel.visibility = View.GONE
        searchPanel.visibility = View.VISIBLE
    }

    private fun showAccountList(connected: Boolean) {
        connectedHeading.visibility = if (connected) View.VISIBLE else View.GONE
        connectedCount.visibility = if (connected) View.VISIBLE else View.GONE
        accountList.visibility = if (connected) View.VISIBLE else View.GONE
        pendingHeading.visibility = if (connected) View.GONE else View.VISIBLE
        pendingList.visibility = if (connected) View.GONE else View.VISIBLE
    }

    private fun label(value: String) = TextView(this).apply {
        text = value; textSize = 13f; setPadding(0, 8, 0, 2)
    }

    private fun edit(hintText: String, secret: Boolean = false) = EditText(this).apply {
        hint = hintText
        maxLines = 1
        if (secret) inputType = 129
    }

    private fun button(textValue: String, action: () -> Unit) = Button(this).apply {
        text = textValue
        setOnClickListener { action() }
    }

    private fun applyProviderDefaults() {
        val email = emailField.text.toString().trim().lowercase()
        val selected = providers.getOrElse(providerSpinner.selectedItemPosition) { "Auto-detect" }
        val domain = email.substringAfter("@", "")
        val choice = if (selected == "Auto-detect") when {
            domain == "gmail.com" || domain == "googlemail.com" -> "Gmail"
            domain in listOf("outlook.com", "hotmail.com", "live.com", "msn.com") -> "Outlook / Hotmail"
            domain == "yahoo.com" || domain.endsWith(".yahoo.com") -> "Yahoo"
            domain == "videotron.ca" -> "Videotron"
            domain == "bell.net" || domain == "sympatico.ca" -> "Bell / Sympatico"
            domain == "sasktel.net" -> "SaskTel"
            else -> "Custom IMAP / POP"
        } else selected
        val settings = when (choice) {
            "Gmail" -> "imap.gmail.com"
            "Outlook / Hotmail" -> "outlook.office365.com"
            "Yahoo" -> "imap.mail.yahoo.com"
            "Videotron" -> "imap.videotron.ca"
            "Bell / Sympatico" -> "imap.bell.net"
            "SaskTel" -> "mail.sasktel.net"
            else -> ""
        }
        if (settings.isNotBlank()) serverField.setText(settings)
        protocolSpinner.setSelection(0)
        portField.setText("993")
    }

    private fun autoDetectIncomingSettings() {
        val email = emailField.text.toString().trim()
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            status.text = "Enter a valid email address first."; return
        }
        applyProviderDefaults()
        val server = serverField.text.toString().trim()
        val port = portField.text.toString().toIntOrNull() ?: 993
        status.text = "Checking TLS connection to $server:$port..."
        thread {
            val result = try {
                val socket = javax.net.ssl.SSLSocketFactory.getDefault().createSocket() as javax.net.ssl.SSLSocket
                socket.soTimeout = 8000
                socket.connect(java.net.InetSocketAddress(server, port), 8000)
                socket.startHandshake()
                socket.close()
                true
            } catch (_: Exception) { false }
            runOnUiThread {
                status.text = if (result) "TLS connection successful. Add the account to verify login."
                else "TLS check failed. Confirm server, port and network settings."
            }
        }
    }

    private fun addAndVerifyAccount() {
        val email = emailField.text.toString().trim()
        val password = passwordField.text.toString()
        val server = serverField.text.toString().trim()
        val protocol = protocolSpinner.selectedItem.toString()
        val port = portField.text.toString().toIntOrNull()
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() ||
            password.isBlank() || server.isBlank() || port == null || port !in 1..65535) {
            status.text = "Enter a valid email, password and incoming server."; return
        }
        if (accounts.any { it.email.equals(email, true) }) {
            status.text = "This email is already saved."; return
        }
        val account = MailAccount(email, password, server, protocol, port)
        accounts.add(account)
        saveData()
        renderAccounts()
        passwordField.text.clear()
        status.text = "Verifying $email..."
        verifyAccount(accounts.indexOf(account))
    }

    private fun verifyAccount(index: Int) {
        if (index !in accounts.indices) return
        val account = accounts[index]
        thread {
            val result = testConnection(account)
            runOnUiThread {
                val current = accounts.indexOfFirst { it.email.equals(account.email, true) }
                if (current >= 0) {
                    accounts[current].verified = result.first
                    saveData()
                    renderAccounts()
                }
                status.text = "${account.email}: ${result.second}"
            }
        }
    }

    private fun testConnection(account: MailAccount): Pair<Boolean, String> {
        var store: Store? = null
        return try {
            val (protocol, props) = mailProperties(account)
            store = Session.getInstance(props).getStore(protocol)
            store.connect(account.server, account.port, account.email, account.password)
            val inbox = store.getFolder("INBOX")
            inbox.open(Folder.READ_ONLY)
            val count = inbox.messageCount
            inbox.close(false)
            store.close()
            true to "Connected successfully. Inbox has $count message(s)."
        } catch (e: Exception) {
            try { store?.close() } catch (_: Exception) {}
            false to "Not connected: ${e.message ?: e.javaClass.simpleName}. Provider app password or OAuth may be required."
        }
    }

    private fun mailProperties(account: MailAccount): Pair<String, Properties> {
        val protocol = if (account.protocol == "POP3S") "pop3s" else "imaps"
        val props = Properties().apply {
            put("mail.store.protocol", protocol)
            put("mail.$protocol.host", account.server)
            put("mail.$protocol.port", account.port.toString())
            put("mail.$protocol.ssl.enable", "true")
            put("mail.$protocol.ssl.checkserveridentity", "true")
            put("mail.$protocol.connectiontimeout", "15000")
            put("mail.$protocol.timeout", "15000")
            put("mail.$protocol.fetchsize", "32768")
        }
        return protocol to props
    }

    private fun renderAccounts() {
        accountList.removeAllViews()
        pendingList.removeAllViews()
        val connected = accounts.filter { it.verified }
        val pending = accounts.filterNot { it.verified }
        connectedCount.text = "${connected.size} connected account(s)"
        showAccountList(true)
        if (connected.isEmpty()) accountList.addView(TextView(this).apply { text = "No connected accounts yet." })
        connected.forEach { addAccountRow(it, true, accountList) }
        if (pending.isEmpty()) pendingList.addView(TextView(this).apply { text = "No pending accounts." })
        pending.forEach { addAccountRow(it, false, pendingList) }
    }

    private fun addAccountRow(account: MailAccount, isConnected: Boolean, target: LinearLayout) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 10, 8, 10)
        }
        panel.addView(TextView(this).apply {
            text = "${account.email}\n${account.protocol} • ${account.server}:${account.port}\n${if (isConnected) "✓ Connected and authenticated" else "Not verified / connection failed"}"
            textSize = 14f
        })
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        actions.addView(Button(this).apply {
            text = if (isConnected) "Reconnect" else "Verify"
            setOnClickListener {
                val i = accounts.indexOf(account)
                if (i >= 0) { status.text = "Verifying ${account.email}..."; verifyAccount(i) }
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(Button(this).apply {
            text = "Remove"
            setOnClickListener {
                accounts.remove(account); saveData(); renderAccounts()
                status.text = "Removed ${account.email}."
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(actions)
        target.addView(panel)
        target.addView(View(this).apply {
            setBackgroundColor(0xFFDDDDDD.toInt())
            layoutParams = LinearLayout.LayoutParams(-1, 1)
        })
    }

    private fun searchAllAccounts(attachmentsOnly: Boolean = false) {
        if (searching) return
        val query = searchField.text.toString().trim()
        if (!attachmentsOnly && query.isBlank()) {
            output.text = "Enter text or an attachment filename to search."; return
        }
        val connected = accounts.filter { it.verified }
        if (connected.isEmpty()) {
            output.text = "No connected accounts. Add and verify an account first."; return
        }
        searching = true
        output.text = "Searching ${connected.size} connected account(s)..."
        thread {
            val results = mutableListOf<String>()
            connected.forEach { account ->
                results.addAll(searchAccount(account, query, attachmentsOnly))
            }
            runOnUiThread {
                searching = false
                output.text = if (results.isEmpty()) "No matching messages found."
                else "Found ${results.size} matching message(s):\n\n" + results.joinToString("\n\n--------------------\n\n")
            }
        }
    }

    private fun searchAccount(account: MailAccount, query: String, attachmentsOnly: Boolean): List<String> {
        if (account.protocol == "POP3S") return listOf("${account.email}: POP3 does not support mailbox-folder search. Reconfigure this account with IMAP if your provider supports it.")
        var store: Store? = null
        val found = mutableListOf<String>()
        try {
            val (protocol, props) = mailProperties(account)
            store = Session.getInstance(props).getStore(protocol)
            store.connect(account.server, account.port, account.email, account.password)
            val folders = mutableListOf<Folder>()
            fun collect(folder: Folder, depth: Int) {
                if (depth > 5) return
                try {
                    if (folder.exists() && (folder.type and Folder.HOLDS_MESSAGES) != 0) folders.add(folder)
                    if ((folder.type and Folder.HOLDS_FOLDERS) != 0) {
                        folder.list().forEach { collect(it, depth + 1) }
                    }
                } catch (_: Exception) {}
            }
            collect(store.defaultFolder, 0)
            for (folder in folders) {
                try {
                    folder.open(Folder.READ_ONLY)
                    val messages = folder.messages
                    val start = (messages.size - 300).coerceAtLeast(0)
                    for (i in messages.size - 1 downTo start) {
                        val msg = messages[i]
                        val names = attachmentNames(msg)
                        val body = if (attachmentsOnly) "" else extractText(msg)
                        val haystack = "${msg.subject ?: ""}\n$body\n${names.joinToString(" ")}"
                        val matches = if (attachmentsOnly) names.isNotEmpty()
                            else haystack.contains(query, ignoreCase = true)
                        if (matches) {
                            val date = msg.sentDate?.toString() ?: ""
                            val subject = msg.subject ?: "(No subject)"
                            found.add("Account: ${account.email}\nFolder: ${folder.fullName}\nSubject: $subject\nDate: $date\nAttachments: ${if (names.isEmpty()) "None" else names.joinToString(", ")}")
                        }
                    }
                    folder.close(false)
                } catch (_: Exception) {
                    try { if (folder.isOpen) folder.close(false) } catch (_: Exception) {}
                }
            }
        } catch (e: Exception) {
            found.add("${account.email}: Search error: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            try { store?.close() } catch (_: Exception) {}
        }
        return found
    }

    private fun attachmentNames(part: Part): List<String> {
        val result = mutableListOf<String>()
        try {
            val filename = part.fileName
            val disposition = part.disposition
            if (!filename.isNullOrBlank() &&
                (disposition.equals(Part.ATTACHMENT, true) || disposition.equals(Part.INLINE, true) || !part.isMimeType("text/*"))) {
                result.add(filename)
            }
            if (part.isMimeType("multipart/*")) {
                val multi = part.content as Multipart
                for (i in 0 until multi.count) result.addAll(attachmentNames(multi.getBodyPart(i)))
            }
        } catch (_: Exception) {}
        return result.distinct()
    }

    private fun extractText(part: Part): String {
        return try {
            if (part.isMimeType("text/plain")) part.content?.toString().orEmpty()
            else if (part.isMimeType("text/html")) android.text.Html.fromHtml(part.content?.toString().orEmpty(), android.text.Html.FROM_HTML_MODE_LEGACY).toString()
            else if (part.isMimeType("multipart/*")) {
                val multi = part.content as Multipart
                (0 until multi.count).joinToString("\n") { extractText(multi.getBodyPart(it)) }
            } else ""
        } catch (_: Exception) { "" }
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey("Emailv4Key", null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(
            "Emailv4Key", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    private fun saveData() {
        try {
            val root = JSONObject()
            val array = JSONArray()
            accounts.forEach { a ->
                array.put(JSONObject().put("email", a.email).put("password", a.password)
                    .put("server", a.server).put("protocol", a.protocol).put("port", a.port)
                    .put("verified", a.verified))
            }
            root.put("accounts", array)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val encrypted = cipher.doFinal(root.toString().toByteArray(Charsets.UTF_8))
            val packed = cipher.iv + encrypted
            getSharedPreferences("emailv4_secure", MODE_PRIVATE).edit()
                .putString("data", Base64.encodeToString(packed, Base64.NO_WRAP)).apply()
        } catch (e: Exception) {
            if (::status.isInitialized) status.text = "Could not securely save data: ${e.message}"
        }
    }

    private fun loadData() {
        try {
            val encoded = getSharedPreferences("emailv4_secure", MODE_PRIVATE).getString("data", null) ?: return
            val packed = Base64.decode(encoded, Base64.NO_WRAP)
            require(packed.size > 12)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(),
                GCMParameterSpec(128, packed.copyOfRange(0, 12)))
            val root = JSONObject(String(cipher.doFinal(packed.copyOfRange(12, packed.size)), Charsets.UTF_8))
            val array = root.optJSONArray("accounts") ?: JSONArray()
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                accounts.add(MailAccount(
                    item.getString("email"), item.getString("password"), item.getString("server"),
                    item.optString("protocol", "IMAPS"),
                    item.optInt("port", if (item.optString("protocol", "IMAPS") == "POP3S") 995 else 993),
                    false // Re-authenticate after app restart; do not trust a stale connection flag.
                ))
            }
        } catch (_: Exception) { accounts.clear() }
    }
}
