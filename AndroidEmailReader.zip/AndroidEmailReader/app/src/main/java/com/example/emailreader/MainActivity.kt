package com.example.emailreader

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.util.Base64
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.mail.*
import javax.mail.internet.InternetAddress
import java.util.Properties
import kotlin.concurrent.thread

private data class MailAccount(
    val email: String,
    val password: String,
    val server: String,
    val protocol: String = "IMAPS",
    val port: Int = if (protocol == "POP3S") 995 else 993,
    var verified: Boolean = false
)

class MainActivity : Activity() {
    private lateinit var emailField: EditText
    private lateinit var passwordField: EditText
    private lateinit var serverField: EditText
    private lateinit var portField: EditText
    private lateinit var providerSpinner: Spinner
    private lateinit var protocolSpinner: Spinner
    private lateinit var status: TextView
    private lateinit var accountList: LinearLayout
    private lateinit var output: TextView

    private val accounts = mutableListOf<MailAccount>()
    private val importedEmails = linkedSetOf<String>()
    private val importedPasswords = linkedSetOf<String>()

    private val providers = listOf(
        "Auto-detect", "Gmail", "Outlook / Hotmail", "Yahoo",
        "Videotron", "Bell / Sympatico", "SaskTel", "Custom IMAP / POP"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        buildUi()
        renderAccounts()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 16)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        content.addView(TextView(this).apply {
            text = "Emailv5"
            textSize = 28f
            setPadding(0, 0, 0, 4)
        })
        content.addView(TextView(this).apply {
            text = "Manage your own mail accounts, import lists and read inboxes."
            textSize = 14f
            setPadding(0, 0, 0, 14)
        })

        providerSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, providers)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (::emailField.isInitialized) applyProviderDefaults()
                }
            }
        }
        content.addView(label("Provider"))
        content.addView(providerSpinner)

        emailField = edit("Email address")
        emailField.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) applyProviderDefaults() }
        passwordField = edit("Password or provider app password", true)
        serverField = edit("Incoming server")
        portField = edit("Incoming port (993 IMAPS / 995 POP3S)")
        portField.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        protocolSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("IMAPS", "POP3S"))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (::portField.isInitialized) portField.setText(if (position == 1) "995" else "993")
                }
            }
        }
        content.addView(label("Email"))
        content.addView(emailField)
        content.addView(label("Password / app password"))
        content.addView(passwordField)
        content.addView(label("Incoming server (editable)"))
        content.addView(serverField)
        content.addView(label("Incoming port"))
        content.addView(portField)
        content.addView(label("Incoming protocol"))
        content.addView(protocolSpinner)

        content.addView(button("Auto-detect server and port") { autoDetectIncomingSettings() })
        content.addView(button("Add account") { addAccount() })
        content.addView(button("Import CSV / TXT") { showImportChoices() })
        content.addView(button("Clear separate imported lists") {
            importedEmails.clear()
            importedPasswords.clear()
            saveData()
            status.text = "Separate email and password lists cleared."
            renderAccounts()
        })

        status = TextView(this).apply {
            text = "Ready"
            textSize = 14f
            setPadding(0, 14, 0, 12)
        }
        content.addView(status)
        content.addView(TextView(this).apply { text = "ACCOUNTS"; textSize = 19f })
        accountList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(accountList)
        output = TextView(this).apply {
            text = "Inbox messages will appear here."
            textSize = 13f
            setPadding(0, 16, 0, 16)
        }
        content.addView(output)
        content.addView(TextView(this).apply {
            text = "Paired file format: email,password (optional columns: server,protocol,port). Separate email-only and password-only files are stored separately and are never automatically cross-combined. Only add accounts you own."
            textSize = 12f
            setPadding(0, 16, 0, 16)
        })

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 13f
        setPadding(0, 8, 0, 2)
    }

    private fun edit(hintText: String, secret: Boolean = false) = EditText(this).apply {
        hint = hintText
        maxLines = 1
        if (secret) inputType = 129
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun applyProviderDefaults() {
        val email = emailField.text.toString().trim().lowercase()
        val selected = providers.getOrElse(providerSpinner.selectedItemPosition) { "Auto-detect" }
        val domain = email.substringAfter("@", "")
        val choice = if (selected == "Auto-detect") {
            when {
                domain == "gmail.com" || domain == "googlemail.com" -> "Gmail"
                domain in listOf("outlook.com", "hotmail.com", "live.com", "msn.com") -> "Outlook / Hotmail"
                domain == "yahoo.com" || domain.endsWith(".yahoo.com") -> "Yahoo"
                domain == "videotron.ca" -> "Videotron"
                domain == "bell.net" || domain == "sympatico.ca" -> "Bell / Sympatico"
                domain == "sasktel.net" -> "SaskTel"
                else -> "Custom IMAP / POP"
            }
        } else selected

        val serverAndProtocol = when (choice) {
            "Gmail" -> "imap.gmail.com" to "IMAPS"
            "Outlook / Hotmail" -> "outlook.office365.com" to "IMAPS"
            "Yahoo" -> "imap.mail.yahoo.com" to "IMAPS"
            "Videotron" -> "imap.videotron.ca" to "IMAPS"
            "Bell / Sympatico" -> "imap.bell.net" to "IMAPS"
            "SaskTel" -> "mail.sasktel.net" to "IMAPS"
            else -> "" to "IMAPS"
        }
        if (serverAndProtocol.first.isNotBlank()) serverField.setText(serverAndProtocol.first)
        protocolSpinner.setSelection(if (serverAndProtocol.second == "POP3S") 1 else 0)
        if (::portField.isInitialized) portField.setText(if (serverAndProtocol.second == "POP3S") "995" else "993")
    }

    private fun autoDetectIncomingSettings() {
        val email = emailField.text.toString().trim()
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            status.text = "Enter a valid email address first."
            return
        }
        applyProviderDefaults()
        val server = serverField.text.toString().trim()
        val port = portField.text.toString().toIntOrNull() ?: 993
        status.text = "Checking secure connection to $server:$port..."
        thread {
            val reachable = try {
                val socket = javax.net.ssl.SSLSocketFactory.getDefault().createSocket() as javax.net.ssl.SSLSocket
                socket.soTimeout = 8000
                socket.connect(java.net.InetSocketAddress(server, port), 8000)
                socket.sslParameters = socket.sslParameters.apply {
                    endpointIdentificationAlgorithm = "HTTPS"
                }
                socket.startHandshake()
                socket.close()
                true
            } catch (_: Exception) { false }
            runOnUiThread {
                status.text = if (reachable) "Detected $server:$port (TLS connection successful). Use Connect to verify login."
                else "Suggested settings: $server:$port. TLS check failed; verify settings or enter a custom server."
            }
        }
    }

    private fun addAccount() {
        val email = emailField.text.toString().trim()
        val password = passwordField.text.toString()
        val server = serverField.text.toString().trim()
        val protocol = protocolSpinner.selectedItem.toString()
        val port = portField.text.toString().toIntOrNull()
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() ||
            password.isBlank() || server.isBlank() || port == null || port !in 1..65535) {
            status.text = "Enter a valid email, password and incoming server."
            return
        }
        if (accounts.any { it.email.equals(email, true) }) {
            status.text = "That email is already saved."
            return
        }
        accounts.add(MailAccount(email, password, server, protocol, port))
        saveData()
        renderAccounts()
        passwordField.text.clear()
        status.text = "Saved $email securely on this device."
    }

    private fun showImportChoices() {
        val options = arrayOf(
            "Paired accounts (email,password)",
            "Email addresses only",
            "Passwords only"
        )
        AlertDialog.Builder(this)
            .setTitle("What does this file contain?")
            .setItems(options) { _, which -> chooseFile(which) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun chooseFile(importMode: Int) {
        // Use a broad document type: Android providers label CSV files with
        // several different MIME types, so a MIME allow-list can grey them out.
        // The import parser handles the selected text content after selection.
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        pendingImportMode = importMode
        startActivityForResult(intent, 41)
    }

    private var pendingImportMode = 0

    @Deprecated("Deprecated by platform; kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 41 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            when (pendingImportMode) {
                0 -> importPairedAccounts(text)
                1 -> importEmailList(text)
                2 -> importPasswordList(text)
            }
        } catch (e: Exception) {
            status.text = "Import failed: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun importPairedAccounts(text: String) {
        val rows = parseCsv(text)
        var added = 0
        rows.forEachIndexed { index, row ->
            if (index == 0 && row.firstOrNull()?.trim()?.equals("email", true) == true) return@forEachIndexed
            if (row.size < 2) return@forEachIndexed
            val email = row[0].trim()
            val password = row[1]
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() || password.isBlank()) return@forEachIndexed
            val existing = accounts.any { it.email.equals(email, true) }
            if (existing) return@forEachIndexed
            val detected = detectServer(email)
            val server = row.getOrNull(2)?.trim()?.takeIf { it.isNotBlank() } ?: detected.first
            val protocol = row.getOrNull(3)?.trim()?.uppercase()?.takeIf { it in listOf("IMAPS", "POP3S") } ?: detected.second
            val defaultPort = if (protocol == "POP3S") 995 else 993
            val port = row.getOrNull(4)?.trim()?.toIntOrNull()?.takeIf { it in 1..65535 } ?: defaultPort
            accounts.add(MailAccount(email, password, server, protocol, port))
            added++
        }
        saveData()
        renderAccounts()
        status.text = "Imported $added account(s). Invalid and duplicate rows were skipped."
    }

    private fun importEmailList(text: String) {
        var added = 0
        text.lineSequence().map { it.trim().trim('"', '\'') }
            .filter { it.isNotBlank() }
            .forEachIndexed { index, value ->
                if (index == 0 && value.equals("email", true)) return@forEachIndexed
                val candidate = value.substringBefore(',').trim()
                if (android.util.Patterns.EMAIL_ADDRESS.matcher(candidate).matches() && importedEmails.add(candidate)) added++
            }
        saveData()
        renderAccounts()
        status.text = "Imported $added email address(es) into the separate list. No combinations were generated."
    }

    private fun importPasswordList(text: String) {
        var added = 0
        text.lineSequence().map { it.trimEnd('\r') }
            .filter { it.isNotBlank() }
            .forEachIndexed { index, value ->
                val candidate = if (index == 0 && value.trim().equals("password", true)) "" else value
                if (candidate.isNotBlank() && importedPasswords.add(candidate)) added++
            }
        saveData()
        renderAccounts()
        status.text = "Imported $added password(s) into the separate encrypted list. No combinations were generated."
    }

    private fun detectServer(email: String): Pair<String, String> {
        val domain = email.substringAfter("@", "").lowercase()
        return when (domain) {
            "gmail.com", "googlemail.com" -> "imap.gmail.com" to "IMAPS"
            "outlook.com", "hotmail.com", "live.com", "msn.com" -> "outlook.office365.com" to "IMAPS"
            "yahoo.com" -> "imap.mail.yahoo.com" to "IMAPS"
            "videotron.ca" -> "imap.videotron.ca" to "IMAPS"
            "bell.net", "sympatico.ca" -> "imap.bell.net" to "IMAPS"
            "sasktel.net" -> "mail.sasktel.net" to "IMAPS"
            else -> "" to "IMAPS"
        }
    }

    // Supports quoted CSV fields, commas inside quotes and escaped double quotes.
    private fun parseCsv(input: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        while (i < input.length) {
            val c = input[i]
            when {
                c == '"' && quoted && i + 1 < input.length && input[i + 1] == '"' -> { cell.append('"'); i++ }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> { row.add(cell.toString()); cell.setLength(0) }
                (c == '\n' || c == '\r') && !quoted -> {
                    if (c == '\r' && i + 1 < input.length && input[i + 1] == '\n') i++
                    row.add(cell.toString()); cell.setLength(0)
                    if (row.any { it.isNotBlank() }) rows.add(row)
                    row = mutableListOf()
                }
                else -> cell.append(c)
            }
            i++
        }
        row.add(cell.toString())
        if (row.any { it.isNotBlank() }) rows.add(row)
        return rows
    }

    private fun renderAccounts() {
        accountList.removeAllViews()
        accountList.addView(TextView(this).apply {
            text = "Separate lists: ${importedEmails.size} email(s) • ${importedPasswords.size} password(s)"
            textSize = 13f
            setPadding(0, 8, 0, 8)
        })
        if (accounts.isEmpty()) accountList.addView(TextView(this).apply { text = "No paired accounts added yet." })
        accounts.forEachIndexed { index, account ->
            val panel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(8, 12, 8, 12)
            }
            panel.addView(TextView(this).apply {
                text = "${account.email}\n${account.protocol} • ${account.server}:${account.port}\n${if (account.verified) "✓ Verified by successful connection" else "Not yet verified"}"
                textSize = 14f
            })
            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            actions.addView(Button(this).apply {
                text = "Connect"
                setOnClickListener { verifyAccount(index) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            actions.addView(Button(this).apply {
                text = "Read inbox"
                setOnClickListener { readAccount(index) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            actions.addView(Button(this).apply {
                text = "Remove"
                setOnClickListener {
                    accounts.removeAt(index)
                    saveData()
                    renderAccounts()
                    status.text = "Account removed."
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            panel.addView(actions)
            accountList.addView(panel)
            accountList.addView(View(this).apply {
                setBackgroundColor(0xFFDDDDDD.toInt())
                layoutParams = LinearLayout.LayoutParams(-1, 1)
            })
        }
    }

    // A connection check is deliberately user-initiated for one selected account only.
    private fun verifyAccount(index: Int) {
        if (index !in accounts.indices) return
        val account = accounts[index]
        status.text = "Connecting to ${account.email}..."
        thread {
            val result = testConnection(account)
            runOnUiThread {
                account.verified = result.first
                saveData()
                renderAccounts()
                status.text = "${account.email}: ${result.second}"
            }
        }
    }

    private fun readAccount(index: Int) {
        if (index !in accounts.indices) return
        val account = accounts[index]
        status.text = "Reading ${account.email}..."
        thread {
            val report = readRecentMessages(account)
            runOnUiThread {
                output.text = "===== ${account.email} =====\n$report"
                status.text = "Finished reading ${account.email}."
            }
        }
    }

    private fun mailProperties(account: MailAccount): Pair<String, Properties> {
        val protocol = if (account.protocol == "POP3S") "pop3s" else "imaps"
        val props = Properties().apply {
            put("mail.store.protocol", protocol)
            put("mail.$protocol.host", account.server)
            put("mail.$protocol.port", account.port.toString())
            put("mail.$protocol.ssl.enable", "true")
            put("mail.$protocol.ssl.checkserveridentity", "true")
            put("mail.$protocol.connectiontimeout", "15000")
            put("mail.$protocol.timeout", "15000")
        }
        return protocol to props
    }

    private fun testConnection(account: MailAccount): Pair<Boolean, String> {
        var store: Store? = null
        try {
            val (protocol, props) = mailProperties(account)
            store = Session.getInstance(props).getStore(protocol)
            store.connect(account.server, account.port, account.email, account.password)
            val folder = if (protocol == "imaps") store.getFolder("INBOX") else null
            if (folder != null) folder.open(Folder.READ_ONLY)
            val count = folder?.messageCount
            folder?.close(false)
            store.close()
            return true to if (count != null) "Connection successful; inbox contains $count message(s)." else "POP3S connection successful."
        } catch (e: Exception) {
            try { store?.close() } catch (_: Exception) {}
            return false to "Connection failed: ${e.message ?: e.javaClass.simpleName}. Check server settings and provider app-password/OAuth requirements."
        }
    }

    private fun readRecentMessages(account: MailAccount): String {
        var store: Store? = null
        try {
            val (protocol, props) = mailProperties(account)
            store = Session.getInstance(props).getStore(protocol)
            store.connect(account.server, account.port, account.email, account.password)
            val inbox = store.getFolder("INBOX")
            inbox.open(Folder.READ_ONLY)
            val messages = inbox.messages
            val first = (messages.size - 10).coerceAtLeast(0)
            val lines = mutableListOf<String>()
            for (i in messages.size - 1 downTo first) {
                val msg = messages[i]
                val sender = (msg.from?.firstOrNull() as? InternetAddress)?.address ?: "Unknown sender"
                val body = extractPlainText(msg).take(500)
                lines.add("From: $sender\nSubject: ${msg.subject ?: "(No subject)"}\nDate: ${msg.sentDate ?: ""}\n$body")
            }
            inbox.close(false)
            store.close()
            return if (lines.isEmpty()) "No messages found." else lines.joinToString("\n\n--------------------\n\n")
        } catch (e: Exception) {
            try { store?.close() } catch (_: Exception) {}
            return "Could not read inbox: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun extractPlainText(part: Part): String {
        return try {
            if (part.isMimeType("text/plain")) part.content.toString()
            else if (part.isMimeType("multipart/*")) {
                val multi = part.content as Multipart
                (0 until multi.count).mapNotNull { idx ->
                    val child = multi.getBodyPart(idx)
                    if (child.isMimeType("text/plain") || child.isMimeType("multipart/*")) extractPlainText(child) else null
                }.joinToString("\n")
            } else ""
        } catch (_: Exception) { "" }
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey("Emailv4Key", null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(
            "Emailv4Key", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    private fun saveData() {
        try {
            val root = JSONObject()
            val accountArray = JSONArray()
            accounts.forEach { a ->
                accountArray.put(JSONObject()
                    .put("email", a.email).put("password", a.password)
                    .put("server", a.server).put("protocol", a.protocol).put("port", a.port)
                    .put("verified", a.verified))
            }
            root.put("accounts", accountArray)
            root.put("emails", JSONArray(importedEmails.toList()))
            root.put("passwords", JSONArray(importedPasswords.toList()))

            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val encrypted = cipher.doFinal(root.toString().toByteArray(Charsets.UTF_8))
            val packed = cipher.iv + encrypted
            getSharedPreferences("emailv4_secure", MODE_PRIVATE).edit()
                .putString("data", Base64.encodeToString(packed, Base64.NO_WRAP)).apply()
        } catch (e: Exception) {
            if (::status.isInitialized) status.text = "Could not securely save data: ${e.message}"
        }
    }

    private fun loadData() {
        try {
            val encoded = getSharedPreferences("emailv4_secure", MODE_PRIVATE).getString("data", null) ?: return
            val packed = Base64.decode(encoded, Base64.NO_WRAP)
            require(packed.size > 12)
            val iv = packed.copyOfRange(0, 12)
            val encrypted = packed.copyOfRange(12, packed.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            val root = JSONObject(String(cipher.doFinal(encrypted), Charsets.UTF_8))
            val accountArray = root.optJSONArray("accounts") ?: JSONArray()
            for (i in 0 until accountArray.length()) {
                val item = accountArray.getJSONObject(i)
                accounts.add(MailAccount(
                    item.getString("email"), item.getString("password"),
                    item.getString("server"), item.optString("protocol", "IMAPS"),
                    item.optInt("port", if (item.optString("protocol", "IMAPS") == "POP3S") 995 else 993),
                    item.optBoolean("verified", false)
                ))
            }
            val emails = root.optJSONArray("emails") ?: JSONArray()
            for (i in 0 until emails.length()) importedEmails.add(emails.getString(i))
            val passwords = root.optJSONArray("passwords") ?: JSONArray()
            for (i in 0 until passwords.length()) importedPasswords.add(passwords.getString(i))
        } catch (_: Exception) {
            accounts.clear()
            importedEmails.clear()
            importedPasswords.clear()
        }
    }
}
